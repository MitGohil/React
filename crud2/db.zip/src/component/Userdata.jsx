import React, { useEffect, useState } from 'react';
import { MDBTable, MDBTableHead, MDBTableBody } from 'mdb-react-ui-kit';
import { Link, useNavigate } from 'react-router-dom';

export default function Userdata() {
    const [userdata, setUserdata] = useState([])
    const navigate = useNavigate()

    useEffect(() => {
        fetch("http://localhost:4000/posts")
            //     .then((result) => {
            //     return result.json().then((resp) => {
            //         setUserdata(resp)
            //     }).catch((error) => {
            //         console.log(error.msg);
            //     })
            // },[])
            .then(result => result.json())
            .then(resp => setUserdata(resp))
            .catch(error => console.log(error.msg));

    }, [])

    const view = (id) => {
        navigate("/viewuser/" + id)
    }
    const edit = (id) => {
        navigate("/edituser/" + id)
    }

    const delet = (id) => {
        fetch("http://localhost:4000/posts/" + id, {
            method: "DELETE"
        }).then((resp) => {
            window.location.reload();
        })
    }
    return (
        <MDBTable align='middle'>
            <MDBTableHead>
                <tr><Link to="/createuser"><button>Add user</button></Link></tr>
                <tr>
                    <th scope='col'>Id</th>
                    <th scope='col'>Email</th>
                    <th scope='col'>Password</th>
                    <th scope='col'>Actions</th>
                </tr>
            </MDBTableHead>
            <MDBTableBody>

                {
                    userdata && userdata.map((item) =>
                        <tr>
                            <td>{item.id}</td>
                            <td>{item.email}</td>
                            <td>{item.password}</td>
                            <td>
                                <button onClick={() => edit(item.id)} >Edit</button>
                                <button onClick={() => delet(item.id)}>Delete</button>
                                <button onClick={() => { view(item.id) }}>View</button>
                            </td>
                        </tr>
                    )
                }

            </MDBTableBody>
        </MDBTable>
    );
}